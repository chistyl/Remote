# TV Launcher v2.0

以使用者提供的當貝桌面 4.1.7 APK 作為視覺參考重新設計首頁卡片。

## v2.0 UI 更新
- 深藍色漸層首頁背景與精簡導覽列
- 直式大卡片與橫式小卡片兩種版型
- 使用藍色發光焦點框，支援 Android TV 遙控器焦點提示
- 保留 App 啟動、長按管理、資料夾、HDMI 輸入、最近使用、背景圖與多語系功能
- 隱藏 Google Setup Wizard 類別入口

## Build
需要 JDK 17、Android SDK Platform 35、Gradle 8.9。

```bash
gradle :app:assembleDebug :app:assembleRelease
```

Debug APK: `app/build/outputs/apk/debug/app-debug.apk`
Release APK: `app/build/outputs/apk/release/app-release-unsigned.apk`

注意：此版本為依照參考 APK 的視覺素材與卡片風格重新實作，不是原版當貝桌面的原始碼或完整功能複製。HDMI 設定入口仍依各電視廠牌韌體支援情況而定。
