package com.chi.tvremote.protocol

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class SavedTvDevice(val name: String, val host: String)

/** Stores paired TV endpoints locally; the client certificate remains in app-private key storage. */
class PairedDeviceStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("paired_tvs", Context.MODE_PRIVATE)

    fun all(): List<SavedTvDevice> {
        val raw = prefs.getString("devices", "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { index ->
                val item = array.optJSONObject(index) ?: return@mapNotNull null
                val host = item.optString("host").trim()
                if (host.isBlank()) null else SavedTvDevice(item.optString("name", host), host)
            }
        }.getOrDefault(emptyList())
    }

    fun save(name: String, host: String) {
        val updated = (listOf(SavedTvDevice(name.ifBlank { host }, host)) + all().filterNot { it.host == host }).take(12)
        val array = JSONArray()
        updated.forEach { array.put(JSONObject().put("name", it.name).put("host", it.host)) }
        prefs.edit().putString("devices", array.toString()).apply()
    }

    fun remove(host: String) {
        val array = JSONArray()
        all().filterNot { it.host == host }.forEach { array.put(JSONObject().put("name", it.name).put("host", it.host)) }
        prefs.edit().putString("devices", array.toString()).apply()
    }
}
