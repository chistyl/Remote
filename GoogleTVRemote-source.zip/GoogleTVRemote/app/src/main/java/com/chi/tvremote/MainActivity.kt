package com.chi.tvremote

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.consume
import androidx.compose.ui.input.pointer.awaitPointerEvent
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import com.chi.tvremote.protocol.TvPairingClient
import com.chi.tvremote.protocol.TvRemoteClient
import com.chi.tvremote.protocol.PairedDeviceStore
import com.chi.tvremote.protocol.SavedTvDevice
import com.chi.tvremote.discovery.TvDiscovery
import com.chi.tvremote.discovery.TvDevice
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090B0F)
private val Panel = Color(0xFF141922)
private val Panel2 = Color(0xFF1C2430)
private val Accent = Color(0xFF43C7F4)
private val Muted = Color(0xFF8995A5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RemoteTheme { RemoteApp() } }
    }
}

@Composable
private fun RemoteTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Accent,
        onBackground = Color.White, onSurface = Color.White,
        secondary = Accent, onPrimary = Color(0xFF00131B)
    ), content = content)
}

@Composable
private fun RemoteApp() {
    var connected by remember { mutableStateOf(false) }
    var deviceName by remember { mutableStateOf("尚未連線") }
    var tab by remember { mutableStateOf(0) }
    var ip by remember { mutableStateOf("") }
    var typedText by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("請先搜尋或輸入電視 IP 位址") }
    var discovered by remember { mutableStateOf<List<TvDevice>>(emptyList()) }
    var searching by remember { mutableStateOf(false) }
    var pairingPending by remember { mutableStateOf(false) }
    var pin by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val pairingClient = remember(context) { TvPairingClient(context) }
    val remoteClient = remember(context) { TvRemoteClient(context) }
    val deviceStore = remember(context) { PairedDeviceStore(context) }
    var savedDevices by remember { mutableStateOf(deviceStore.all()) }
    var paired by remember { mutableStateOf(false) }
    val discovery = remember(context) {
        TvDiscovery(context, { found -> discovered = found }, { error -> searching = false; notice = error })
    }
    DisposableEffect(discovery, pairingClient, remoteClient) { onDispose { discovery.close(); pairingClient.close(); remoteClient.close() } }

    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Color(0xFF10151D), contentColor = Color.White) {
            NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.SportsEsports, null) }, label = { Text("遙控器") })
            NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Keyboard, null) }, label = { Text("鍵盤") })
            NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Tv, null) }, label = { Text("設備") })
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().background(Bg).padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 22.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("CHI  /  TV REMOTE", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("智慧遙控器", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                }
                Box(Modifier.size(42.dp).clip(CircleShape).background(Panel), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.PowerSettingsNew, null, tint = if (connected) Accent else Muted)
                }
            }
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(if (connected) Color(0xFF45D483) else Color(0xFFFFB44C)))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (connected) deviceName else if (paired) "已配對：$deviceName" else "未連接電視", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text(if (connected) "Remote v2 安全連線中" else if (paired) "已配對；請重新連線" else notice, color = Muted, fontSize = 12.sp)
                }
                TextButton(onClick = { tab = 2 }) { Text("管理", color = Accent) }
            }
            Spacer(Modifier.height(22.dp))
            when (tab) {
                0 -> RemoteScreen(enabled = connected, onCommand = { command ->
                    val key = when (command) {
                        "上" -> 19; "下" -> 20; "左" -> 21; "右" -> 22; "確認 OK" -> 23
                        "返回" -> 4; "首頁" -> 3; "最近使用" -> 187
                        "音量加" -> 24; "音量減" -> 25; "靜音" -> 164
                        "播放暫停" -> 85; "選單" -> 82
                        "電源" -> 26
                        "HDMI 1" -> 243; "HDMI 2" -> 244; "HDMI 3" -> 245; "HDMI 4" -> 246
                        else -> null
                    }
                    if (key != null) scope.launch {
                        try { remoteClient.key(key); notice = "已傳送：$command" }
                        catch (e: Exception) { connected = false; notice = "遙控失敗：${e.localizedMessage ?: "連線中斷"}" }
                    }
                })
                1 -> KeyboardScreen(text = typedText, onText = { typedText = it }, enabled = connected, onSend = {
                    scope.launch {
                        try { remoteClient.sendText(typedText); notice = "已透過電視 IME 傳送文字" }
                        catch (e: Exception) { connected = false; notice = "文字傳送失敗：${e.localizedMessage ?: "連線中斷"}" }
                    }
                })
                else -> DeviceScreen(
                    ip = ip, onIp = { ip = it }, devices = discovered, savedDevices = savedDevices, searching = searching,
                    onSearch = { searching = true; notice = "正在搜尋同一個 Wi-Fi 網路中的 Google TV…"; discovery.start() },
                    onSelectDevice = { device -> ip = device.host; notice = "已選取 ${device.name}（${device.host}），可以開始配對" },
                    onReconnect = { saved ->
                        ip = saved.host
                        deviceName = saved.name
                        notice = "正在使用已保存的配對憑證連線…"
                        scope.launch {
                            try {
                                remoteClient.connect(saved.host)
                                connected = true
                                paired = true
                                notice = "已重新連線：${saved.name}"
                                tab = 0
                                scope.launch { remoteClient.listen { reason -> connected = false; notice = "電視連線中斷：$reason" } }
                            } catch (e: Exception) {
                                connected = false
                                notice = "重新連線失敗：${e.localizedMessage ?: "請重新配對"}"
                            }
                        }
                    },
                    pairingPending = pairingPending, pin = pin, onPin = { pin = it },
                    onConnect = {
                        pairingPending = false
                        notice = "正在建立安全配對連線…"
                        scope.launch {
                            try { notice = pairingClient.begin(ip); pairingPending = true }
                            catch (e: Exception) { pairingPending = false; notice = "配對連線失敗：${e.localizedMessage ?: "請確認 IP 與 Wi-Fi"}" }
                        }
                    },
                    onFinishPairing = {
                        notice = "正在驗證配對碼…"
                        scope.launch {
                            try {
                                notice = pairingClient.finish(pin)
                                pairingPending = false
                                paired = true
                                deviceName = discovered.firstOrNull { it.host == ip }?.name ?: ip
                                deviceStore.save(deviceName, ip)
                                savedDevices = deviceStore.all()
                                notice = "配對成功，正在啟動遙控通道…"
                                remoteClient.connect(ip)
                                connected = true
                                notice = "Remote v2 已連線"
                                tab = 0
                                scope.launch { remoteClient.listen { reason -> connected = false; notice = "電視連線中斷：$reason" } }
                            } catch (e: Exception) { notice = "配對失敗：${e.localizedMessage ?: "請重新確認驗證碼"}" }
                        }
                    }
                )
            }
            Spacer(Modifier.height(10.dp))
            Text("LOCAL NETWORK  •  NO CLOUD ACCOUNT", color = Color(0xFF596575), fontSize = 10.sp, letterSpacing = 1.3.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@Composable
private fun RemoteScreen(enabled: Boolean, onCommand: (String) -> Unit) {
    Text("DIRECTION CONTROL", color = Muted, fontSize = 11.sp, letterSpacing = 1.6.sp, modifier = Modifier.padding(bottom = 12.dp))
    Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
        Box(Modifier.size(258.dp).clip(CircleShape).background(Panel).border(1.dp, Color(0xFF283443), CircleShape))
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            DpadButton("↑", enabled) { onCommand("上") }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                DpadButton("←", enabled) { onCommand("左") }
                Box(Modifier.size(82.dp).clip(CircleShape).background(Accent).clickable(enabled) { onCommand("確認 OK") }, contentAlignment = Alignment.Center) {
                    Text("OK", color = Color(0xFF00131B), fontWeight = FontWeight.Black, fontSize = 20.sp)
                }
                DpadButton("→", enabled) { onCommand("右") }
            }
            DpadButton("↓", enabled) { onCommand("下") }
        }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        ActionTile("返回", Icons.Default.ArrowBack, enabled, Modifier.weight(1f)) { onCommand("返回") }
        ActionTile("首頁", Icons.Default.Home, enabled, Modifier.weight(1f)) { onCommand("首頁") }
        ActionTile("最近使用", Icons.Default.Apps, enabled, Modifier.weight(1f)) { onCommand("最近使用") }
    }
    Spacer(Modifier.height(16.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        ActionTile("音量 −", Icons.Default.VolumeDown, enabled, Modifier.weight(1f)) { onCommand("音量減") }
        ActionTile("靜音", Icons.Default.VolumeOff, enabled, Modifier.weight(1f)) { onCommand("靜音") }
        ActionTile("音量 +", Icons.Default.VolumeUp, enabled, Modifier.weight(1f)) { onCommand("音量加") }
    }
    Spacer(Modifier.height(12.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        ActionTile("播放 / 暫停", Icons.Default.PlayArrow, enabled, Modifier.weight(1f)) { onCommand("播放暫停") }
        ActionTile("選單", Icons.Default.MoreHoriz, enabled, Modifier.weight(1f)) { onCommand("選單") }
        ActionTile("電源", Icons.Default.PowerSettingsNew, enabled, Modifier.weight(1f)) { onCommand("電源") }
    }
    Spacer(Modifier.height(16.dp))
    Text("觸控板  /  滑動移動焦點，點擊確認", color = Muted, fontSize = 11.sp, letterSpacing = 1.sp)
    var dragX by remember { mutableFloatStateOf(0f) }
    var dragY by remember { mutableFloatStateOf(0f) }
    Box(
        Modifier.fillMaxWidth().height(132.dp).clip(RoundedCornerShape(20.dp))
            .background(Panel).border(1.dp, Color(0xFF283443), RoundedCornerShape(20.dp))
            .pointerInput(enabled) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    dragX = 0f
                    dragY = 0f
                    var moved = false
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        if (!change.pressed) break
                        val delta = change.positionChange()
                        dragX += delta.x
                        dragY += delta.y
                        if (kotlin.math.abs(dragX) + kotlin.math.abs(dragY) > 24f) moved = true
                        if (delta.x != 0f || delta.y != 0f) change.consume()
                    }
                    if (enabled) {
                        if (!moved) onCommand("確認 OK")
                        else if (kotlin.math.abs(dragX) > kotlin.math.abs(dragY)) onCommand(if (dragX > 0) "右" else "左")
                        else onCommand(if (dragY > 0) "下" else "上")
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.TouchApp, null, tint = Accent, modifier = Modifier.size(27.dp))
            Spacer(Modifier.height(6.dp))
            Text("觸控操作區", color = Color.White, fontWeight = FontWeight.Medium)
            Text("滑動切換方向・點擊 OK", color = Muted, fontSize = 11.sp)
        }
    }
    Spacer(Modifier.height(14.dp))
    Text("HDMI 輸入快捷鍵（依電視支援）", color = Muted, fontSize = 11.sp)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        (1..4).forEach { n ->
            ActionTile("HDMI $n", Icons.Default.Input, enabled, Modifier.weight(1f)) { onCommand("HDMI $n") }
        }
    }
    Text("提示：HDMI 快捷鍵及電源鍵是否有效，取決於電視韌體；觸控板以方向鍵事件模擬焦點移動。", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp, bottom = 8.dp))
}

@Composable
private fun DpadButton(label: String, enabled: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(70.dp).clip(CircleShape).background(Panel2).clickable(enabled, onClick = onClick), contentAlignment = Alignment.Center) {
        Text(label, color = if (enabled) Color.White else Muted, fontSize = 28.sp, fontWeight = FontWeight.Light)
    }
}

@Composable
private fun ActionTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, enabled: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.height(76.dp).clip(RoundedCornerShape(15.dp)).background(Panel).clickable(enabled, onClick = onClick).padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = if (enabled) Accent else Muted, modifier = Modifier.size(23.dp))
        Spacer(Modifier.height(5.dp))
        Text(label, color = if (enabled) Color.White else Muted, fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun KeyboardScreen(text: String, onText: (String) -> Unit, enabled: Boolean, onSend: () -> Unit) {
    Text("PHONE KEYBOARD", color = Muted, fontSize = 11.sp, letterSpacing = 1.6.sp)
    Spacer(Modifier.height(12.dp))
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        BasicTextField(value = text, onValueChange = onText, enabled = enabled, modifier = Modifier.weight(1f), textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 16.sp), decorationBox = { inner -> if (text.isEmpty()) Text("輸入要在電視搜尋的文字…", color = Muted); inner() })
        IconButton(onClick = onSend, enabled = enabled) { Icon(Icons.Default.Send, null, tint = Accent) }
    }
    Spacer(Modifier.height(18.dp))
    Text("使用手機原生鍵盤輸入，將文字傳送至電視目前焦點欄位。", color = Muted, fontSize = 13.sp)
}

@Composable
private fun DeviceScreen(ip: String, onIp: (String) -> Unit, devices: List<TvDevice>, savedDevices: List<SavedTvDevice>, searching: Boolean, onSearch: () -> Unit, onSelectDevice: (TvDevice) -> Unit, onReconnect: (SavedTvDevice) -> Unit, pairingPending: Boolean, pin: String, onPin: (String) -> Unit, onConnect: () -> Unit, onFinishPairing: () -> Unit) {
    Text("DEVICE CONNECTION", color = Muted, fontSize = 11.sp, letterSpacing = 1.6.sp)
    Spacer(Modifier.height(14.dp))
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Wifi, null, tint = Accent, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Text("搜尋附近的 Google TV", color = Color.White, fontWeight = FontWeight.SemiBold); Text("透過同一個 Wi-Fi 網路探索設備", color = Muted, fontSize = 12.sp) }
        TextButton(onClick = onSearch) { Text(if (searching) "搜尋中…" else "搜尋", color = Accent) }
    }
    if (savedDevices.isNotEmpty()) {
        Spacer(Modifier.height(14.dp))
        Text("已配對設備（${savedDevices.size}）", color = Color.White, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        savedDevices.forEach { saved ->
            Row(
                Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(13.dp))
                    .background(Panel).clickable { onReconnect(saved) }.padding(13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Tv, null, tint = Accent)
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(saved.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text(saved.host, color = Muted, fontSize = 12.sp)
                }
                Text("重新連線", color = Accent, fontSize = 12.sp)
            }
        }
    }
    if (devices.isNotEmpty()) {
        Spacer(Modifier.height(14.dp))
        Text("搜尋到的設備（${devices.size}）", color = Color.White, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        devices.forEach { device ->
            Row(
                Modifier.fillMaxWidth().padding(bottom = 8.dp).clip(RoundedCornerShape(13.dp))
                    .background(Panel).clickable { onSelectDevice(device) }.padding(13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Tv, null, tint = Accent)
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(device.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("${device.host}  •  Remote 2", color = Muted, fontSize = 12.sp)
                }
                Icon(Icons.Default.ChevronRight, null, tint = Muted)
            }
        }
    } else if (searching) {
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Accent, strokeWidth = 2.dp)
            Spacer(Modifier.width(10.dp))
            Text("正在探索區域網路…", color = Muted, fontSize = 12.sp)
        }
    }
    Spacer(Modifier.height(16.dp))
    Text("手動輸入 IP 位址", color = Color.White, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(value = ip, onValueChange = onIp, modifier = Modifier.fillMaxWidth(), placeholder = { Text("例如 192.168.1.100") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = Color(0xFF34404E), focusedTextColor = Color.White, unfocusedTextColor = Color.White))
    Spacer(Modifier.height(12.dp))
    Button(onClick = onConnect, enabled = ip.isNotBlank() && !pairingPending, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color(0xFF00131B))) { Text("開始配對", fontWeight = FontWeight.Bold) }
    if (pairingPending) {
        Spacer(Modifier.height(16.dp))
        Text("輸入電視顯示的 6 位數十六進位驗證碼", color = Color.White, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = pin, onValueChange = { onPin(it.uppercase().filter { c -> c in "0123456789ABCDEF" }.take(6)) }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("例如 A1B2C3") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = Color(0xFF34404E), focusedTextColor = Color.White, unfocusedTextColor = Color.White))
        Spacer(Modifier.height(10.dp))
        Button(onClick = onFinishPairing, enabled = pin.length == 6, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF45D483), contentColor = Color(0xFF06150D))) { Text("確認配對", fontWeight = FontWeight.Bold) }
    }
    Spacer(Modifier.height(18.dp))
    Text("首次配對時，請依電視畫面顯示的驗證碼完成授權。憑證會保存在手機 App 私有空間。", color = Muted, fontSize = 12.sp)
}
