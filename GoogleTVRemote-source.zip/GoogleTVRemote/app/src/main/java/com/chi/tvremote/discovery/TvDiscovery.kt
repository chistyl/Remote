package com.chi.tvremote.discovery

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import java.net.Inet4Address
import java.util.concurrent.atomic.AtomicBoolean

/** Discovers Android TV Remote v2 endpoints on the current Wi-Fi network. */
class TvDiscovery(context: Context, private val onUpdate: (List<TvDevice>) -> Unit, private val onError: (String) -> Unit) {
    private val appContext = context.applicationContext
    private val nsd = appContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val wifi = appContext.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val devices = linkedMapOf<String, TvDevice>()
    private val running = AtomicBoolean(false)
    private var multicastLock: WifiManager.MulticastLock? = null

    private val discoveryListener = object : NsdManager.DiscoveryListener {
        override fun onDiscoveryStarted(serviceType: String) = Unit
        override fun onServiceFound(serviceInfo: NsdServiceInfo) {
            if (!serviceInfo.serviceType.contains("androidtvremote2", ignoreCase = true)) return
            nsd.resolveService(serviceInfo, object : NsdManager.ResolveListener {
                override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) {
                    // Some devices briefly fail resolution while waking; the next scan can retry.
                }
                override fun onServiceResolved(info: NsdServiceInfo) {
                    val address = info.host?.hostAddress ?: return
                    val device = TvDevice(
                        name = info.serviceName.ifBlank { "Google TV" },
                        host = address,
                        port = info.port.takeIf { it > 0 } ?: 6466
                    )
                    synchronized(devices) {
                        devices[address] = device
                        onUpdate(devices.values.sortedBy { it.name.lowercase() })
                    }
                }
            })
        }
        override fun onServiceLost(serviceInfo: NsdServiceInfo) {
            // Keep discovered devices visible for this scan; a brief multicast loss should not
            // make the device list flicker while the TV is waking or changing power state.
        }
        override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
            running.set(false)
            releaseMulticast()
            onError("無法啟動網路搜尋（錯誤 $errorCode），請確認手機與電視連接同一個 Wi-Fi。")
        }
        override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {
            onError("停止搜尋時發生錯誤（$errorCode）")
        }
        override fun onDiscoveryStopped(serviceType: String) { releaseMulticast() }
    }

    fun start() {
        if (!running.compareAndSet(false, true)) return
        synchronized(devices) { devices.clear() }
        onUpdate(emptyList())
        try {
            multicastLock = wifi.createMulticastLock("chi-tv-remote-mdns").apply {
                setReferenceCounted(false)
                acquire()
            }
            nsd.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discoveryListener)
        } catch (e: Exception) {
            running.set(false)
            releaseMulticast()
            onError("搜尋啟動失敗：${e.localizedMessage ?: "未知錯誤"}")
        }
    }

    fun stop() {
        if (!running.compareAndSet(true, false)) return
        try { nsd.stopServiceDiscovery(discoveryListener) } catch (_: Exception) { releaseMulticast() }
    }

    fun close() = stop()

    private fun releaseMulticast() {
        try { multicastLock?.takeIf { it.isHeld }?.release() } catch (_: Exception) { }
        multicastLock = null
    }

    companion object { private const val SERVICE_TYPE = "_androidtvremote2._tcp." }
}

data class TvDevice(val name: String, val host: String, val port: Int) {
    val isIpv4: Boolean get() = runCatching { java.net.InetAddress.getByName(host) is Inet4Address }.getOrDefault(false)
}
