package com.chi.tvremote.protocol

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream

/** Minimal protobuf wire helpers used by Android TV Remote v2's Polo pairing channel. */
internal object ProtoWire {
    fun varint(value: Long): ByteArray {
        var v = value
        val out = ByteArrayOutputStream()
        while (v and -128L != 0L) {
            out.write(((v and 0x7f) or 0x80).toInt())
            v = v ushr 7
        }
        out.write(v.toInt())
        return out.toByteArray()
    }

    fun uint(field: Int, value: Long): ByteArray = concat(varint((field shl 3).toLong()), varint(value))
    fun bytes(field: Int, value: ByteArray): ByteArray = concat(varint(((field shl 3) or 2).toLong()), varint(value.size.toLong()), value)
    fun string(field: Int, value: String): ByteArray = bytes(field, value.toByteArray(Charsets.UTF_8))
    fun concat(vararg values: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        values.forEach { out.write(it) }
        return out.toByteArray()
    }

    fun writeFrame(output: OutputStream, payload: ByteArray) {
        output.write(varint(payload.size.toLong()))
        output.write(payload)
        output.flush()
    }

    fun readFrame(input: InputStream): ByteArray {
        var length = 0L
        var shift = 0
        while (true) {
            val b = input.read()
            if (b < 0) throw java.io.EOFException("TV closed the pairing connection")
            length = length or ((b and 0x7f).toLong() shl shift)
            if ((b and 0x80) == 0) break
            shift += 7
            if (shift >= 64) throw java.io.IOException("Invalid protobuf frame length")
        }
        if (length < 0 || length > 1024 * 1024) throw java.io.IOException("Pairing frame too large")
        val data = ByteArray(length.toInt())
        var offset = 0
        while (offset < data.size) {
            val count = input.read(data, offset, data.size - offset)
            if (count < 0) throw java.io.EOFException("Incomplete pairing frame")
            offset += count
        }
        return data
    }

    data class Field(val number: Int, val wireType: Int, val numberValue: Long = 0, val bytesValue: ByteArray = byteArrayOf())

    fun fields(data: ByteArray): List<Field> {
        val result = mutableListOf<Field>()
        var p = 0
        fun readVarint(): Long {
            var value = 0L
            var shift = 0
            while (p < data.size && shift < 64) {
                val b = data[p++].toInt() and 0xff
                value = value or ((b and 0x7f).toLong() shl shift)
                if (b and 0x80 == 0) return value
                shift += 7
            }
            throw java.io.IOException("Malformed protobuf varint")
        }
        while (p < data.size) {
            val tag = readVarint().toInt()
            val field = tag ushr 3
            val wire = tag and 7
            when (wire) {
                0 -> result += Field(field, wire, numberValue = readVarint())
                1 -> { if (p + 8 > data.size) throw java.io.IOException("Truncated fixed64"); p += 8 }
                2 -> {
                    val n = readVarint().toInt()
                    if (n < 0 || p + n > data.size) throw java.io.IOException("Truncated length-delimited field")
                    result += Field(field, wire, bytesValue = data.copyOfRange(p, p + n)); p += n
                }
                5 -> { if (p + 4 > data.size) throw java.io.IOException("Truncated fixed32"); p += 4 }
                else -> throw java.io.IOException("Unsupported protobuf wire type $wire")
            }
        }
        return result
    }
}
