# CHI TV Remote — APK 建置

目前版本：`0.6.0`（`versionCode 6`）

## 在 Android Studio 建置

1. 安裝 Android Studio 與 JDK 17。
2. 開啟本專案根目錄 `GoogleTVRemote`。
3. 在 SDK Manager 安裝 Android SDK Platform 35 與 Android SDK Build-Tools 35.0.0。
4. 等待 Gradle Sync 完成。
5. 選擇 **Build > Build Bundle(s) / APK(s) > Build APK(s)**。
6. Debug APK 預設輸出位置：`app/build/outputs/apk/debug/app-debug.apk`。

本專案使用 Android Gradle Plugin 8.7.3，建議 Gradle 8.9、JDK 17。

## GitHub Actions 自動建置

專案已附 `.github/workflows/android-build.yml`。將整個專案推送到 GitHub 的 `main` 或 `master` 分支，或在 GitHub Actions 頁面手動執行 **Android APK Build**。成功後到該次 workflow run 的 **Artifacts** 下載 `CHI-TV-Remote-v0.6.0-debug`，解壓後即可取得 `app-debug.apk`。

## 注意

- 目前提供的是 Debug APK 建置流程；不是 Play Store 發佈用的簽署版 APK。
- Debug APK 使用 Android 預設 debug signing key。
- 必須在具備網路的 Android Studio 或 GitHub Actions runner 上下載 Gradle、Android SDK 與 Maven 依賴。
- 實機配對、按鍵、IME 文字輸入及各廠牌 HDMI / 電源相容性仍須在目標電視上測試。
