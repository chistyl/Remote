# CHI TV Remote — Android TV Remote v2 client

Traditional Chinese UI, dark graphite / cyan accent. Package: `com.chi.tvremote`.

## Current status — v0.6.0

This is an Android Studio source project with the dark graphite / cyan Compose UI, mDNS discovery, TLS PIN pairing, and a first implementation of the Android TV Remote v2 control channel. It is **not yet a verified release APK**: this environment does not contain Android SDK / Gradle, and no physical Google TV has been available for interoperability testing.

Implemented in source:
- mDNS discovery for `_androidtvremote2._tcp.` and manual IP entry
- RSA-2048 client identity and PKCS#12 persistence in app-private storage
- TLS 1.2 pairing channel on TCP 6467 and six-character hexadecimal PIN validation
- TLS 1.2 remote channel on TCP 6466
- RemoteConfigure / RemoteSetActive handshake
- Protobuf-varint framed RemoteKeyInject commands for D-pad, Back, Home, volume, mute, play/pause, menu, power, and HDMI input shortcuts (device-dependent)
- Ping request / response handling to keep the remote session alive
- Unicode text insertion through RemoteImeBatchEdit, including IME counter synchronization

Known limitations:
- Must be tested against the target TV model and its Android TV Remote Service version.
- Unicode text is now sent through RemoteImeBatchEdit with IME counter synchronization. Chinese composition behavior still depends on the TV IME and must be verified on the target model; this implementation inserts committed text and does not mirror live composition/candidate selection.
- Power and HDMI input shortcuts are key-injection requests only; whether they work depends on TV firmware, active service state, and device support. They are not guaranteed power-on / input-selection APIs.
- Certificate trust is permissive during TLS because TVs use self-signed certificates; production hardening should bind the TV identity to the completed PIN pairing and validate it on subsequent sessions.
- A connection or command is not considered verified until tested on a physical TV. The paired-device list stores up to 12 TV names/IP endpoints in app-private preferences; the client identity is persisted by the existing certificate manager and currently shared across those endpoints.

## Build environment

- Android Studio Ladybug or newer
- JDK 17
- Android SDK Platform 35
- Gradle 8.9+ (Generate the Gradle wrapper as described below)

Install Gradle 8.9+ (or use Android Studio's bundled Gradle setup), then from this folder run:

```bash
gradle wrapper --gradle-version 8.9
./gradlew :app:assembleDebug
```

Alternatively, open the project in Android Studio after generating the wrapper. The APK output path is `app/build/outputs/apk/debug/app-debug.apk`.

Additional v0.5.0 changes:
- Correct RemoteConfigure feature negotiation using the TV-advertised feature mask.
- Correct RemoteSetActive handshake response (no false intermediate configure acknowledgement).
- Unicode IME batch insertion using RemoteImeBatchEdit, RemoteEditInfo, and RemoteImeObject.
- Synchronize IME and field counters from TV responses.
- Echo the TV's ping request token in RemotePingResponse.
- Save up to 12 paired TV endpoints locally and allow reconnect without repeating PIN pairing when the TV still trusts the stored client certificate.

Additional v0.6.0 changes:
- Gesture touchpad: a swipe maps to one dominant-axis DPAD event; a tap maps to OK. This is focus navigation, not absolute pointer or mouse control.
- Added power-key and HDMI 1–4 key shortcuts. These are best-effort Android key injections and may be ignored by some TV models.
- Made the remote screen vertically scrollable to accommodate the expanded controls.

## Protocol and build notes

- Discovery: mDNS `_androidtvremote2._tcp.`
- Pairing: mutual TLS over TCP 6467
- Remote control: mutual TLS over TCP 6466
- Messages: protobuf with varint length-prefix framing
- All network operations run on `Dispatchers.IO`; UI callbacks use coroutines.

## Build environment

- Android Studio Ladybug or newer
- JDK 17
- Android SDK Platform 35
- Gradle 8.9+

If Gradle is installed, from this folder run:

```bash
gradle wrapper --gradle-version 8.9
./gradlew :app:assembleDebug
```

Alternatively, open this folder in Android Studio and let it sync the Gradle project. The expected debug APK path is `app/build/outputs/apk/debug/app-debug.apk` after a successful build.

## Privacy

The app is designed for local-network communication only. The client private key and certificate are stored in app-private storage. No cloud account, analytics, or advertising is included.

## Development history

- v0.2.0: mDNS service discovery, multicast lock, device list, manual IP fallback.
- v0.3.0: RSA identity, PKCS#12 persistence, TLS PIN pairing on TCP 6467.
- v0.4.0: initial TLS remote session on TCP 6466 and key injection prototype.
- v0.5.0: corrected feature negotiation and RemoteSetActive handshake, Unicode IME batch insertion, ping echo, and saved paired-device endpoints.
- v0.6.0: added gesture touchpad (swipe maps to one DPAD event; tap maps to OK), power key shortcut, HDMI 1–4 input key shortcuts, and a vertically scrollable remote screen. HDMI and power behavior depend on TV firmware; the touchpad is not mouse-pointer control.

Protocol reference used for interoperability research: public `androidtvremote2` / `remotemessage.proto` implementations and public Android TV Remote v2 protocol descriptions. This project uses a minimal Kotlin wire encoder/decoder rather than generated protobuf classes.
