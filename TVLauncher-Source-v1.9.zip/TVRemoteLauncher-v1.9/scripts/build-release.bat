@echo off
setlocal
cd /d "%~dp0.."
call scripts\check-build-env.bat
if errorlevel 1 exit /b 1
if exist gradlew.bat (
  if exist gradle\wrapper\gradle-wrapper.jar (
    call gradlew.bat --no-daemon :app:assembleRelease
  ) else (
    gradle --no-daemon :app:assembleRelease
  )
) else (
  gradle --no-daemon :app:assembleRelease
)
if errorlevel 1 exit /b 1
if not exist dist mkdir dist
copy /Y app\build\outputs\apk\release\app-release.apk dist\TVLauncher-release.apk >nul
if errorlevel 1 exit /b 1
echo [SUCCESS] %CD%\dist\TVLauncher-release.apk
if "%TVLAUNCHER_STORE_FILE%"=="" echo [WARNING] No signing environment supplied; verify APK signature before distribution.
endlocal
