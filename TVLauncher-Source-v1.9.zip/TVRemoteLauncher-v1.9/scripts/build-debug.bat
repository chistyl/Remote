@echo off
setlocal
cd /d "%~dp0.."
call scripts\check-build-env.bat
if errorlevel 1 exit /b 1
if exist gradlew.bat (
  if exist gradle\wrapper\gradle-wrapper.jar (
    call gradlew.bat --no-daemon :app:assembleDebug
  ) else (
    gradle --no-daemon :app:assembleDebug
  )
) else (
  gradle --no-daemon :app:assembleDebug
)
if errorlevel 1 exit /b 1
if not exist dist mkdir dist
copy /Y app\build\outputs\apk\debug\app-debug.apk dist\TVLauncher-debug.apk >nul
if errorlevel 1 exit /b 1
echo [SUCCESS] %CD%\dist\TVLauncher-debug.apk
endlocal
