#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
./scripts/check-build-env.sh
if [[ -x ./gradlew && -f gradle/wrapper/gradle-wrapper.jar ]]; then
  ./gradlew --no-daemon :app:assembleDebug
else
  gradle --no-daemon :app:assembleDebug
fi
mkdir -p dist
cp app/build/outputs/apk/debug/app-debug.apk dist/TVLauncher-debug.apk
echo "[SUCCESS] $ROOT/dist/TVLauncher-debug.apk"
