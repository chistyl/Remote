@echo off
setlocal
cd /d "%~dp0.."
set "APK=%~1"
if "%APK%"=="" set "APK=app\build\outputs\apk\release\app-release.apk"
if not exist "%APK%" (echo [ERROR] APK not found: %APK%& exit /b 1)
if "%ANDROID_SDK_ROOT%"=="" if "%ANDROID_HOME%"=="" (echo [ERROR] Set ANDROID_SDK_ROOT or ANDROID_HOME.& exit /b 1)
if not "%ANDROID_SDK_ROOT%"=="" (set "SDK=%ANDROID_SDK_ROOT%") else (set "SDK=%ANDROID_HOME%")
set "SIGNER="
for /d %%D in ("%SDK%\build-tools\*") do if exist "%%~D\apksigner.bat" set "SIGNER=%%~D\apksigner.bat"
if "%SIGNER%"=="" (echo [ERROR] apksigner.bat not found.& exit /b 1)
call "%SIGNER%" verify --verbose --print-certs "%APK%"
if errorlevel 1 exit /b %errorlevel%
echo [OK] APK signature verification passed.
