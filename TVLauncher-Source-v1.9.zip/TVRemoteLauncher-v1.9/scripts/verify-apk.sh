#!/usr/bin/env bash
set -euo pipefail
APK="${1:-app/build/outputs/apk/release/app-release.apk}"
[[ -f "$APK" ]] || { echo "[ERROR] APK not found: $APK" >&2; exit 1; }
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
[[ -n "$SDK" ]] || { echo "[ERROR] Set ANDROID_SDK_ROOT or ANDROID_HOME." >&2; exit 1; }
APKSIGNER=""
for f in "$SDK"/build-tools/*/apksigner; do [[ -x "$f" ]] && APKSIGNER="$f"; done
[[ -n "$APKSIGNER" ]] || { echo "[ERROR] apksigner not found in Android SDK Build Tools." >&2; exit 1; }
"$APKSIGNER" verify --verbose --print-certs "$APK"
echo "[OK] APK signature verification passed."
