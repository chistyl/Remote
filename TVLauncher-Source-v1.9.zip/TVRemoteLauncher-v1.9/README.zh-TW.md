

## V1.9 建置交付補強

- 建置腳本會先切換到專案根目錄，從任意工作目錄執行也不會找錯路徑。
- 若專案包含完整 Gradle Wrapper（`gradlew` 與 `gradle-wrapper.jar`）則優先使用；否則使用系統 Gradle。
- 成功建置後會複製 APK 至 `dist/TVLauncher-debug.apk` 或 `dist/TVLauncher-release.apk`。
- 此原始碼封裝未附 Gradle Wrapper JAR，也不包含 Android SDK。請在已安裝 JDK 17、Gradle 8.9、Android SDK Platform 35 與 Build Tools 的電腦執行。
- 本版沒有加入網路更新、強制更新、自動下載或廣告推播程式。
