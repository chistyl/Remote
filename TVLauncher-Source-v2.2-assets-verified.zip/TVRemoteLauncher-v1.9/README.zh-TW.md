# TV Launcher v2.1

以使用者提供的當貝桌面 4.1.7 APK 作為視覺參考重新設計首頁卡片。

## v2.1 UI 更新
- 深藍色漸層首頁背景與精簡導覽列
- 直式大卡片與橫式小卡片兩種版型
- 使用藍色發光焦點框，支援 Android TV 遙控器焦點提示
- 保留 App 啟動、長按管理、資料夾、HDMI 輸入、最近使用、背景圖與多語系功能
- 隱藏 Google Setup Wizard 類別入口

## Build
需要 JDK 17、Android SDK Platform 35、Gradle 8.9。

```bash
gradle :app:assembleDebug :app:assembleRelease
```

Debug APK: `app/build/outputs/apk/debug/app-debug.apk`
Release APK: `app/build/outputs/apk/release/app-release-unsigned.apk`

注意：此版本為依照參考 APK 的視覺素材與卡片風格重新實作，不是原版當貝桌面的原始碼或完整功能複製。HDMI 設定入口仍依各電視廠牌韌體支援情況而定。


## v2.2 視覺重建
- 首頁改為全螢幕桌布底圖，不再使用 v2.1 自製漸層背景與頂部工具列。
- 導入當貝 4.1.7 APK 的桌布、App 底圖與焦點框素材。
- 工具功能集中至遙控器選單入口，保留 HDMI、資料夾、語言與圖示大小切換。
- 本版仍需在實際 Android TV 上核對焦點尺寸、位置與首頁分頁行為。


## v2.2 原版素材核對（2026-10-30）

已從使用者提供的當貝桌面 4.1.7 APK 匯入原始圖檔：`dangbei_original_*.png`，並將桌布替換為 APK 內 `res/drawable-nodpi/bg_launcher_default_new.webp`。這些圖檔保留原始像素尺寸與透明度。

注意：目前 MainActivity 首頁仍保留自製 GridView；原版 APK 的 layout XML 是 Android 二進位 XML，尚未完整解碼並重建其 View hierarchy。因此此版本是「原版素材匯入驗證包」，不是當貝 4.1.7 完整介面復刻版。
