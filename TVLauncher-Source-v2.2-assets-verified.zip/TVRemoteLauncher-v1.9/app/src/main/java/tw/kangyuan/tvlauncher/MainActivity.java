package tw.kangyuan.tvlauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.ComponentName;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.FrameLayout;
import android.graphics.drawable.GradientDrawable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.PopupMenu;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private static final String PREF = "tv_launcher_prefs";
    private static final String KEY_SMALL = "small_cards";
    private static final String KEY_FOLDERS = "folders_v1";
    private static final String KEY_LANGUAGE = "language_v1";
    private static final String KEY_BG = "background_uri_v1";
    private static final String KEY_ORDER = "app_order_v1";
    private static final String KEY_RECENT = "recent_apps_v1";
    private String language = "繁體中文";
    private GridView grid;
    private AppAdapter adapter;
    private final List<AppEntry> apps = new ArrayList<>();
    private final List<FolderEntry> folders = new ArrayList<>();
    private final List<Object> homeItems = new ArrayList<>();
    private boolean smallCards;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        smallCards = getPreferences(MODE_PRIVATE).getBoolean(KEY_SMALL, false);
        language = getSharedPreferences(PREF, MODE_PRIVATE).getString(KEY_LANGUAGE, "繁體中文");
        loadFolders(); buildHome(); loadApps();
    }

    @Override protected void onResume() {
        super.onResume();
        // Refresh the installed-app list whenever the user returns from another app.
        if (adapter != null) loadApps();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private String tr(String key) {
        String[][] rows = {
            {"我的應用程式","My Apps","我的应用","アプリ","내 앱"},
            {"新增資料夾","New Folder","新建文件夹","フォルダー追加","폴더 추가"},
            {"資料夾名稱","Folder name","文件夹名称","フォルダー名","폴더 이름"},
            {"取消","Cancel","取消","キャンセル","취소"},
            {"建立","Create","创建","作成","만들기"},
            {"資料夾已建立","Folder created","文件夹已创建","フォルダーを作成しました","폴더 생성됨"},
            {"開啟資料夾","Open folder","打开文件夹","フォルダーを開く","폴더 열기"},
            {"加入／移除 App","Manage apps","管理应用","アプリを管理","앱 관리"},
            {"重新命名","Rename","重命名","名前を変更","이름 변경"},
            {"刪除資料夾","Delete folder","删除文件夹","フォルダーを削除","폴더 삭제"},
            {"此資料夾尚無 App","This folder is empty","此文件夹暂无应用","このフォルダーは空です","폴더가 비어 있습니다"},
            {"管理 App","Manage apps","管理应用","アプリを管理","앱 관리"},
            {"關閉","Close","关闭","閉じる","닫기"},
            {"完成","Done","完成","完了","완료"},
            {"儲存","Save","保存","保存","저장"},
            {"刪除資料夾？","Delete folder?","删除文件夹？","フォルダーを削除しますか？","폴더를 삭제할까요?"},
            {"資料夾內的 App 會回到首頁，不會解除安裝。","Apps will return to Home and will not be uninstalled.","文件夹中的应用将返回主页，不会被卸载。","アプリはホームに戻り、アンインストールされません。","앱은 홈으로 이동하며 삭제되지 않습니다."},
            {"資料夾已刪除","Folder deleted","文件夹已删除","フォルダーを削除しました","폴더 삭제됨"},
            {"加入資料夾","Add to folder","加入文件夹","フォルダーに追加","폴더에 추가"},
            {"請先新增資料夾","Create a folder first","请先创建文件夹","先にフォルダーを作成してください","먼저 폴더를 만드세요"},
            {"已加入資料夾","Added to folder","已加入文件夹","フォルダーに追加しました","폴더에 추가됨"},
            {"開啟","Open","打开","開く","열기"},
            {"App 資訊","App info","应用信息","アプリ情報","앱 정보"},
            {"系統設定","System settings","系统设置","システム設定","시스템 설정"},
            {"HDMI 輸入","HDMI input","HDMI 输入","HDMI入力","HDMI 입력"},
            {"重新整理 App","Refresh apps","刷新应用","アプリを更新","앱 새로고침"},
            {"切換圖示大小","Toggle icon size","切换图标大小","アイコンサイズ切替","아이콘 크기 전환"},
            {"語言","Language","语言","言語","언어"},
            {"背景圖片","Wallpaper","背景图片","壁紙","배경 이미지"},
            {"選擇背景圖片","Choose wallpaper","选择背景图片","壁紙を選択","배경 이미지 선택"},
            {"最近使用","Recently used","最近使用","最近使用","최근 사용"},
            {"大圖示","Large icons","大图标","大きいアイコン","큰 아이콘"},
            {"小圖示","Small icons","小图标","小さいアイコン","작은 아이콘"},
            {"TV Launcher","TV Launcher","TV Launcher","TV Launcher","TV Launcher"},
            {"背景","Wallpaper","背景","背景","배경"},
            {"設定","Settings","设置","設定","설정"},
            {"刪除","Delete","删除","削除","삭제"},
            {"移到首頁最前","Move to front","移到首页最前","先頭に移動","맨 앞으로 이동"},
            {"尚無使用紀錄","No recent apps","暂无使用记录","履歴はありません","최근 사용 기록 없음"},
            {"將「","Add ","将「","「","「"},
            {"加入資料夾","Add to folder","加入文件夹","フォルダーに追加","폴더에 추가"}
        };
        int col = language.equals("English") ? 1 : language.equals("简体中文") ? 2 : language.equals("日本語") ? 3 : language.equals("한국어") ? 4 : 0;
        for (String[] row : rows) if (row[0].equals(key)) return row[col];
        return key;
    }
    private TextView text(String value, int size, int color) { TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); return t; }

    private TextView navItem(String label, Runnable action) {
        TextView item = text(label, 14, Color.rgb(226,235,248));
        item.setGravity(Gravity.CENTER); item.setPadding(dp(13), 0, dp(13), 0); item.setFocusable(true); item.setClickable(true);
        GradientDrawable normal = new GradientDrawable(); normal.setColor(Color.argb(105,34,54,82)); normal.setCornerRadius(dp(18));
        item.setBackground(normal); item.setOnClickListener(v -> action.run());
        item.setOnFocusChangeListener((v, focused) -> { v.setScaleX(focused?1.06f:1f); v.setScaleY(focused?1.06f:1f); GradientDrawable d=new GradientDrawable(); d.setColor(focused?Color.rgb(31,104,190):Color.argb(105,34,54,82)); d.setCornerRadius(dp(18)); d.setStroke(dp(focused?2:1), focused?Color.rgb(126,190,255):Color.argb(80,150,180,220)); v.setBackground(d); });
        return item;
    }

    private void buildHome() {
        FrameLayout root = new FrameLayout(this);
        root.setFocusable(true);
        root.setClipChildren(false);
        root.setClipToPadding(false);
        ImageView wallpaper = new ImageView(this);
        wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP);
        wallpaper.setImageResource(R.drawable.dangbei_wallpaper);
        String bg = getSharedPreferences(PREF, MODE_PRIVATE).getString(KEY_BG, "");
        if (!bg.isEmpty()) try { wallpaper.setImageURI(Uri.parse(bg)); } catch(Exception ignored) {}
        root.addView(wallpaper, new FrameLayout.LayoutParams(-1,-1));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(64), dp(38), dp(64), dp(34));
        content.setClipChildren(false);
        content.setClipToPadding(false);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1,-1);
        root.addView(content, cp);

        // Dangbei-style home: clean wallpaper canvas, no custom toolbar row.
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("", 20, Color.WHITE);
        top.addView(brand, new LinearLayout.LayoutParams(0, dp(42), 1));
        TextView tools = text("⋯", 30, Color.WHITE);
        tools.setGravity(Gravity.CENTER);
        tools.setFocusable(true);
        tools.setOnClickListener(v -> showHomeTools());
        tools.setOnFocusChangeListener((v, f) -> { v.setScaleX(f?1.18f:1f); v.setScaleY(f?1.18f:1f); });
        top.addView(tools, new LinearLayout.LayoutParams(dp(54), dp(48)));
        content.addView(top, new LinearLayout.LayoutParams(-1, dp(54)));

        grid = new GridView(this);
        grid.setHorizontalSpacing(dp(smallCards ? 18 : 26));
        grid.setVerticalSpacing(dp(smallCards ? 12 : 18));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(android.R.color.transparent);
        grid.setPadding(dp(4), dp(12), dp(4), dp(10));
        grid.setClipChildren(false);
        grid.setClipToPadding(false);
        applyGridSizing();
        adapter = new AppAdapter();
        grid.setAdapter(adapter);
        content.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
        grid.requestFocus();
    }

    private void showHomeTools() {
        new AlertDialog.Builder(this).setTitle("TV Remote Launcher")
            .setItems(new String[]{tr("切換圖示大小"),tr("新增資料夾"),tr("語言"),tr("最近使用"),tr("背景圖片"),"HDMI",tr("設定"),tr("重新整理 App")},(d,w)->{
                if(w==0){smallCards=!smallCards;getPreferences(MODE_PRIVATE).edit().putBoolean(KEY_SMALL,smallCards).apply();buildHome();loadApps();}
                else if(w==1)createFolder(); else if(w==2)showLanguageMenu(null); else if(w==3)showRecent(); else if(w==4)chooseWallpaper(); else if(w==5)openHdmi(); else if(w==6)openSettings(); else loadApps();
            }).show();
    }

    private void applyGridSizing() {
        if (grid != null) grid.setNumColumns(smallCards ? 7 : 5);
    }

    private void loadApps() {
        apps.clear(); PackageManager pm = getPackageManager();
        // Query both TV (LEANBACK) and regular Android (LAUNCHER) activities.
        // Some TV firmware exposes a mixed catalogue, so do not use LAUNCHER
        // only as a fallback: merge both lists and de-duplicate by package.
        Intent leanback = new Intent(Intent.ACTION_MAIN); leanback.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        Intent normal = new Intent(Intent.ACTION_MAIN); normal.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> candidates = new ArrayList<>();
        List<ResolveInfo> tvApps = pm.queryIntentActivities(leanback, 0);
        List<ResolveInfo> phoneApps = pm.queryIntentActivities(normal, 0);
        if (tvApps != null) candidates.addAll(tvApps);
        if (phoneApps != null) candidates.addAll(phoneApps);
        Set<String> seen = new HashSet<>();
        for (ResolveInfo ri : candidates) {
            if (ri.activityInfo == null) continue;
            String pkg = ri.activityInfo.packageName;
            if (pkg == null || pkg.equals(getPackageName()) || pkg.toLowerCase().contains("setupwizard") || !seen.add(pkg)) continue;
            AppEntry e = new AppEntry();
            CharSequence label = ri.loadLabel(pm);
            e.label = label == null ? pkg : label.toString();
            e.pkg = pkg;
            e.activity = ri.activityInfo.name;
            try { e.icon = ri.loadIcon(pm); } catch (Exception ignored) { e.icon = getDrawable(android.R.drawable.sym_def_app_icon); }
            apps.add(e);
        }
        Collections.sort(apps, Comparator.comparing(a -> a.label.toLowerCase()));
        String orderRaw = getSharedPreferences(PREF, MODE_PRIVATE).getString(KEY_ORDER, "");
        if (!orderRaw.isEmpty()) { String[] order = orderRaw.split("\\|"); List<AppEntry> sorted = new ArrayList<>(); for (String pkg : order) { AppEntry a=findApp(pkg); if(a!=null && !sorted.contains(a)) sorted.add(a); } for(AppEntry a:apps) if(!sorted.contains(a)) sorted.add(a); apps.clear(); apps.addAll(sorted); }
        // Remove package references that are no longer installed.
        for (FolderEntry f : folders) { List<String> valid = new ArrayList<>(); for (String p : f.packages) if (findApp(p) != null) valid.add(p); f.packages.clear(); f.packages.addAll(valid); }
        saveFolders(); rebuildHome();
    }
    private AppEntry findApp(String pkg) { for (AppEntry a : apps) if (a.pkg.equals(pkg)) return a; return null; }
    private void rebuildHome() {
        homeItems.clear(); Set<String> grouped = new HashSet<>();
        for (FolderEntry f : folders) { homeItems.add(f); grouped.addAll(f.packages); }
        for (AppEntry a : apps) if (!grouped.contains(a.pkg)) homeItems.add(a);
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void loadFolders() {
        folders.clear(); String raw = getSharedPreferences(PREF, MODE_PRIVATE).getString(KEY_FOLDERS, "[]");
        try { JSONArray arr = new JSONArray(raw); for (int i=0;i<arr.length();i++) { JSONObject o=arr.getJSONObject(i); FolderEntry f=new FolderEntry(); f.name=o.optString("name","資料夾"); JSONArray ps=o.optJSONArray("packages"); if(ps!=null) for(int j=0;j<ps.length();j++) f.packages.add(ps.getString(j)); folders.add(f); } } catch(Exception ignored) { folders.clear(); }
    }
    private void saveFolders() {
        JSONArray arr = new JSONArray(); try { for(FolderEntry f:folders) { JSONObject o=new JSONObject(); o.put("name",f.name); JSONArray ps=new JSONArray(); for(String p:f.packages) ps.put(p); o.put("packages",ps); arr.put(o); } } catch(Exception ignored) {}
        getSharedPreferences(PREF, MODE_PRIVATE).edit().putString(KEY_FOLDERS,arr.toString()).apply();
    }
    private void createFolder() {
        EditText input = new EditText(this); input.setSingleLine(true); input.setHint(tr("資料夾名稱"));
        new AlertDialog.Builder(this).setTitle(tr("新增資料夾")).setView(input).setNegativeButton(tr("取消"),null).setPositiveButton(tr("建立"),(d,w)->{
            String name=input.getText().toString().trim(); if(name.isEmpty()) name="新資料夾";
            FolderEntry f=new FolderEntry(); f.name=name; folders.add(f); saveFolders(); rebuildHome(); Toast.makeText(this,tr("資料夾已建立"),Toast.LENGTH_SHORT).show();
        }).show();
    }
    private void folderMenu(FolderEntry folder) {
        new AlertDialog.Builder(this).setTitle(folder.name).setItems(new String[]{tr("開啟資料夾"),tr("加入／移除 App"),tr("重新命名"),tr("刪除資料夾")},(d,w)->{
            if(w==0) openFolder(folder); else if(w==1) editFolderApps(folder); else if(w==2) renameFolder(folder); else confirmDeleteFolder(folder);
        }).show();
    }
    private void openFolder(FolderEntry folder) {
        List<AppEntry> members=new ArrayList<>(); for(String p:folder.packages){AppEntry a=findApp(p);if(a!=null)members.add(a);}
        if(members.isEmpty()){ new AlertDialog.Builder(this).setTitle(folder.name).setMessage(tr("此資料夾尚無 App")).setPositiveButton(tr("管理 App"),(d,w)->editFolderApps(folder)).setNegativeButton(tr("關閉"),null).show(); return; }
        String[] labels=new String[members.size()]; for(int i=0;i<members.size();i++)labels[i]=members.get(i).label;
        new AlertDialog.Builder(this).setTitle(folder.name).setItems(labels,(d,w)->launchApp(members.get(w))).setPositiveButton(tr("管理 App"),(d,w)->editFolderApps(folder)).setNegativeButton(tr("關閉"),null).show();
    }
    private void editFolderApps(FolderEntry folder) {
        String[] labels=new String[apps.size()]; boolean[] checked=new boolean[apps.size()];
        for(int i=0;i<apps.size();i++){labels[i]=apps.get(i).label;checked[i]=folder.packages.contains(apps.get(i).pkg);}
        new AlertDialog.Builder(this).setTitle(tr("加入／移除 App") + ": " + folder.name).setMultiChoiceItems(labels,checked,(d,w,isChecked)->{String p=apps.get(w).pkg;if(isChecked){for(FolderEntry f:folders)f.packages.remove(p);if(!folder.packages.contains(p))folder.packages.add(p);}else folder.packages.remove(p);})
            .setPositiveButton(tr("完成"),(d,w)->{saveFolders();rebuildHome();}).setNegativeButton(tr("取消"),(d,w)->{loadFolders();rebuildHome();}).show();
    }
    private void addAppToFolder(AppEntry app) {
        if(folders.isEmpty()){Toast.makeText(this,tr("請先新增資料夾"),Toast.LENGTH_SHORT).show();return;}
        String[] names=new String[folders.size()];for(int i=0;i<folders.size();i++)names[i]=folders.get(i).name;
        new AlertDialog.Builder(this).setTitle("將「"+app.label+"」加入資料夾").setItems(names,(d,w)->{for(FolderEntry f:folders)f.packages.remove(app.pkg);folders.get(w).packages.add(app.pkg);saveFolders();rebuildHome();Toast.makeText(this,tr("已加入資料夾"),Toast.LENGTH_SHORT).show();}).show();
    }
    private void renameFolder(FolderEntry folder) { EditText input=new EditText(this);input.setSingleLine(true);input.setText(folder.name);new AlertDialog.Builder(this).setTitle(tr("重新命名")).setView(input).setNegativeButton(tr("取消"),null).setPositiveButton(tr("儲存"),(d,w)->{String n=input.getText().toString().trim();if(!n.isEmpty())folder.name=n;saveFolders();rebuildHome();}).show(); }
    private void confirmDeleteFolder(FolderEntry folder) { new AlertDialog.Builder(this).setTitle(tr("刪除資料夾？")).setMessage(tr("資料夾內的 App 會回到首頁，不會解除安裝。")).setNegativeButton(tr("取消"),null).setPositiveButton(tr("刪除"),(d,w)->{folders.remove(folder);saveFolders();rebuildHome();}).show(); }
    private void launchApp(AppEntry app) {
        String raw = getSharedPreferences(PREF, MODE_PRIVATE).getString(KEY_RECENT, "");
        List<String> recent = new ArrayList<>(); if(!raw.isEmpty()) for(String x:raw.split("\\|")) if(!x.equals(app.pkg)) recent.add(x);
        recent.add(0, app.pkg); while(recent.size()>12) recent.remove(recent.size()-1);
        getSharedPreferences(PREF, MODE_PRIVATE).edit().putString(KEY_RECENT, android.text.TextUtils.join("|",recent)).apply();
        // Launch the exact activity discovered through LEANBACK_LAUNCHER or LAUNCHER.
        // getLaunchIntentForPackage() can return null for TV-only apps that expose
        // a Leanback entry point but no regular phone launcher activity.
        try {
            Intent launch = new Intent(Intent.ACTION_MAIN);
            launch.setComponent(new ComponentName(app.pkg, app.activity));
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        } catch (Exception e) {
            Toast.makeText(this, "無法啟動 App", Toast.LENGTH_SHORT).show();
        }
    }
    private void showLanguageMenu(View anchor) {
        final String[] langs={"繁體中文","简体中文","English","日本語","한국어"};
        PopupMenu menu = anchor==null ? null : new PopupMenu(this,anchor);
        if(menu!=null){ for(String l:langs) menu.getMenu().add(l); menu.setOnMenuItemClickListener(item->{setLanguage(item.getTitle().toString());return true;}); menu.show(); }
        else new AlertDialog.Builder(this).setTitle(tr("語言")).setItems(langs,(d,w)->setLanguage(langs[w])).show();
    }
    private void setLanguage(String lang) { language=lang; getSharedPreferences(PREF,MODE_PRIVATE).edit().putString(KEY_LANGUAGE,lang).apply(); buildHome(); loadApps(); }
    private void chooseWallpaper() { Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE); try { startActivityForResult(i,701); } catch(Exception e){Toast.makeText(this,"無法開啟圖片選擇器",Toast.LENGTH_SHORT).show();} }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==701 && resultCode==RESULT_OK && data!=null && data.getData()!=null){ Uri u=data.getData(); try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){} getSharedPreferences(PREF,MODE_PRIVATE).edit().putString(KEY_BG,u.toString()).apply(); buildHome(); loadApps(); } }
    private void showRecent() { String raw=getSharedPreferences(PREF,MODE_PRIVATE).getString(KEY_RECENT,""); List<AppEntry> list=new ArrayList<>(); if(!raw.isEmpty()) for(String p:raw.split("\\|")){AppEntry a=findApp(p);if(a!=null)list.add(a);} if(list.isEmpty()){new AlertDialog.Builder(this).setTitle(tr("最近使用")).setMessage(tr("尚無使用紀錄")).setPositiveButton(tr("關閉"),null).show();return;} String[] names=new String[list.size()];for(int i=0;i<list.size();i++)names[i]=list.get(i).label;new AlertDialog.Builder(this).setTitle(tr("最近使用")).setItems(names,(d,w)->launchApp(list.get(w))).setNegativeButton(tr("關閉"),null).show(); }
    private void moveAppToFront(AppEntry app) { apps.remove(app); apps.add(0,app); List<String> order=new ArrayList<>();for(AppEntry a:apps)order.add(a.pkg);getSharedPreferences(PREF,MODE_PRIVATE).edit().putString(KEY_ORDER,android.text.TextUtils.join("|",order)).apply(); rebuildHome(); }
    private void openHdmi() { Intent i=new Intent("android.settings.TV_INPUTS_SETTINGS");try{startActivity(i);}catch(Exception ex){try{startActivity(new Intent(Settings.ACTION_SETTINGS));}catch(Exception ignored){Toast.makeText(this,"此電視未提供 HDMI 輸入設定入口",Toast.LENGTH_SHORT).show();}} }
    private void openSettings() { try{startActivity(new Intent(Settings.ACTION_SETTINGS));}catch(Exception e){Toast.makeText(this,"無法開啟系統設定",Toast.LENGTH_SHORT).show();} }
    @Override public boolean onKeyDown(int keyCode,KeyEvent event) {
        if(keyCode==KeyEvent.KEYCODE_MENU){new AlertDialog.Builder(this).setTitle("TV Launcher").setItems(new String[]{tr("重新整理 App"),tr("切換圖示大小"),tr("新增資料夾"),tr("系統設定"),tr("HDMI 輸入"),tr("最近使用"),tr("語言"),tr("背景圖片")},(d,w)->{if(w==0)loadApps();else if(w==1){smallCards=!smallCards;getPreferences(MODE_PRIVATE).edit().putBoolean(KEY_SMALL,smallCards).apply();applyGridSizing();adapter.notifyDataSetChanged();}else if(w==2)createFolder();else if(w==3)openSettings();else if(w==4)openHdmi();else if(w==5)showRecent();else if(w==6)showLanguageMenu(null);else chooseWallpaper();}).show();return true;}return super.onKeyDown(keyCode,event);
    }
    private class AppEntry { String label,pkg,activity; Drawable icon; }
    private class FolderEntry { String name; final List<String> packages=new ArrayList<>(); }
    private class AppAdapter extends BaseAdapter {
        @Override public int getCount(){return homeItems.size();}
        @Override public Object getItem(int p){return homeItems.get(p);}
        @Override public long getItemId(int p){return p;}
        @Override public View getView(int p,View convert,ViewGroup parent){
            Object item=homeItems.get(p);
            FrameLayout card=new FrameLayout(MainActivity.this); card.setFocusable(true); card.setFocusableInTouchMode(true); card.setClipChildren(false); card.setClipToPadding(false);
            ImageView cardBg=new ImageView(MainActivity.this); cardBg.setScaleType(ImageView.ScaleType.FIT_XY); cardBg.setImageResource(R.drawable.dangbei_app_tile); card.addView(cardBg,new FrameLayout.LayoutParams(-1,-1));
            LinearLayout content=new LinearLayout(MainActivity.this); content.setOrientation(LinearLayout.VERTICAL); content.setGravity(Gravity.CENTER); content.setPadding(dp(smallCards?8:12),dp(smallCards?8:14),dp(smallCards?8:12),dp(smallCards?6:10));
            ImageView icon=new ImageView(MainActivity.this); icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            int iconSize=smallCards?dp(66):dp(108); LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(iconSize,iconSize); ip.gravity=Gravity.CENTER;
            TextView label;
            if(item instanceof AppEntry){AppEntry app=(AppEntry)item;icon.setImageDrawable(app.icon);label=text(app.label,smallCards?11:14,Color.WHITE);card.setOnClickListener(v->launchApp(app));card.setOnLongClickListener(v->{new AlertDialog.Builder(MainActivity.this).setTitle(app.label).setItems(new String[]{tr("開啟"),tr("加入資料夾"),tr("App 資訊"),tr("移到首頁最前")},(d,w)->{if(w==0)launchApp(app);else if(w==1)addAppToFolder(app);else if(w==3)moveAppToFront(app);else{Intent i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);i.setData(Uri.parse("package:"+app.pkg));startActivity(i);}}).show();return true;});}
            else{FolderEntry f=(FolderEntry)item;icon.setImageResource(android.R.drawable.ic_menu_agenda);label=text(f.name,smallCards?11:14,Color.WHITE);card.setOnClickListener(v->openFolder(f));card.setOnLongClickListener(v->{folderMenu(f);return true;});}
            content.addView(icon,ip); label.setGravity(Gravity.CENTER);label.setMaxLines(2);label.setEllipsize(android.text.TextUtils.TruncateAt.END);label.setPadding(0,dp(smallCards?4:8),0,0);content.addView(label,new LinearLayout.LayoutParams(-1,dp(smallCards?28:38))); card.addView(content,new FrameLayout.LayoutParams(-1,-1));
            ImageView focus=new ImageView(MainActivity.this);focus.setScaleType(ImageView.ScaleType.FIT_XY);focus.setImageResource(smallCards?R.drawable.dangbei_focus_small:R.drawable.dangbei_focus_large);focus.setVisibility(View.GONE);card.addView(focus,new FrameLayout.LayoutParams(-1,-1));
            card.setOnFocusChangeListener((v,focused)->{focus.setVisibility(focused?View.VISIBLE:View.GONE);v.setScaleX(focused?1.045f:1f);v.setScaleY(focused?1.045f:1f);});
            int height=smallCards?dp(126):dp(214); card.setLayoutParams(new GridView.LayoutParams(-1,height)); return card;
        }
    }
}